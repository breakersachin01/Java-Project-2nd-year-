import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProgressReportFrame extends JFrame implements ActionListener {

    JLabel nameLabel = new JLabel("Name:");
    JTextField nameTextField = new JTextField();
    JLabel rollNumberLabel = new JLabel("Roll Number:");
    JTextField rollNumberTextField = new JTextField();
    JLabel sectionLabel = new JLabel("Section:");
    JTextField sectionTextField = new JTextField();
    JLabel subject1Label = new JLabel("English:");
    JTextField subject1TextField = new JTextField();
    JLabel subject2Label = new JLabel("Hindi:");
    JTextField subject2TextField = new JTextField();
    JLabel subject3Label = new JLabel("Maths:");
    JTextField subject3TextField = new JTextField();
    JLabel subject4Label = new JLabel("Science:");
    JTextField subject4TextField = new JTextField();
    JButton generateButton = new JButton("Generate Progress Report");

    public ProgressReportFrame() {
        setTitle("Progress Report Generator");
        setLayout(null);
        setResizable(true);
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        nameLabel.setBounds(20, 20, 100, 25);
        nameTextField.setBounds(120, 20, 250, 25);
        rollNumberLabel.setBounds(20, 50, 100, 25);
        rollNumberTextField.setBounds(120, 50, 250, 25);
        sectionLabel.setBounds(20, 80, 100, 25);
        sectionTextField.setBounds(120, 80, 250, 25);
        subject1Label.setBounds(20, 110, 100, 25);
        subject1TextField.setBounds(120, 110, 250, 25);
        subject2Label.setBounds(20, 140, 100, 25);
        subject2TextField.setBounds(120, 140, 250, 25);
        subject3Label.setBounds(20, 170, 100, 25);
        subject3TextField.setBounds(120, 170, 250, 25);
        subject4Label.setBounds(20, 200, 100, 25);
        subject4TextField.setBounds(120, 200, 250, 25);
        generateButton.setBounds(20, 240, 350, 25);

        add(nameLabel);
        add(nameTextField);
        add(rollNumberLabel);
        add(rollNumberTextField);
        add(sectionLabel);
        add(sectionTextField);
        add(subject1Label);
        add(subject1TextField);
        add(subject2Label);
        add(subject2TextField);
        add(subject3Label);
        add(subject3TextField);
        add(subject4Label);
        add(subject4TextField);
        add(generateButton);

        generateButton.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == generateButton) {
            String name = nameTextField.getText();
            String rollNumber = rollNumberTextField.getText();
            String section = sectionTextField.getText();
            int subject1Marks = Integer.parseInt(subject1TextField.getText());
            int subject2Marks = Integer.parseInt(subject2TextField.getText());
            int subject3Marks = Integer.parseInt(subject3TextField.getText());
            int subject4Marks = Integer.parseInt(subject4TextField.getText());
            generateProgressReport(name, rollNumber, section, subject1Marks, subject2Marks, subject3Marks,
                    subject4Marks);
        }
    }

    public void generateProgressReport(String name, String rollNumber, String section, int subject1Marks,
            int subject2Marks, int subject3Marks, int subject4Marks) {
        int totalMarks = subject1Marks + subject2Marks + subject3Marks + subject4Marks;
        float percentage = (float) totalMarks / 4;

        String report = "Name: " + name + "\n";
        report += "Roll Number: " + rollNumber + "\n";
        report += "Section: " + section + "\n";
        report += "--------------------------------------\n";
        report += "Subject      |     Marks\n";
        report += "--------------------------------------\n";
        report += "English      |     " + subject1Marks + "\n";
        report += "Hindi          |     " + subject2Marks + "\n";
        report += "Maths         |     " + subject3Marks + "\n";
        report += "Science      |     " + subject4Marks + "\n";
        report += "--------------------------------------\n";
        report += "Total Marks: " + totalMarks + "\n";
        report += "Percentage: " + percentage + "%\n";
        if (percentage <= 30) {
            report += "     FAILED";
        } else {
            report += "     PASSED";
        }
        JOptionPane.showMessageDialog(null, report);
    }

    public static void main(String[] args) {
        new ProgressReportFrame();
    }
}