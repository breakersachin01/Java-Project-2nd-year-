import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame implements ActionListener {

    JLabel usernameLabel = new JLabel("Username:");
    JTextField usernameTextField = new JTextField();
    JLabel passwordLabel = new JLabel("Password:");
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("Login");
    
    public LoginFrame() {
        setTitle("Login");
        setLayout(null);
        setResizable(true);
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        usernameLabel.setBounds(20, 20, 80, 25);
        usernameTextField.setBounds(100, 20, 165, 25);
        passwordLabel.setBounds(20, 50, 80, 25);
        passwordField.setBounds(100, 50, 165, 25);
        loginButton.setBounds(100, 85, 80, 25);
        
        add(usernameLabel);
        add(usernameTextField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);
        
        loginButton.addActionListener(this);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameTextField.getText();
            String password = new String(passwordField.getPassword());
            if (username.equals("admin") && password.equals("password")) {
                new ProgressReportFrame();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        new LoginFrame();
    }

}
